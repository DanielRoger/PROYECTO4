/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Roger
 */
public class Usuari {
    //atributos
    private int usu_id;
    private String usu_nom;
    private String usu_pass;
    
    //constructor (pongo todos pero creo que solo hay que poner el que tiene todo ya que no puede pasar sin nombre y/o contraseña)
    public Usuari() {
    }

    public Usuari(int usu_id, String usu_nom, String usu_pass) {
        this.usu_id = usu_id;
        this.usu_nom = usu_nom;
        this.usu_pass = usu_pass;
    }

    public Usuari(String usu_nom, String usu_pass) {
        this.usu_nom = usu_nom;
        this.usu_pass = usu_pass;
    }
    
    //getters & setters

    public int getUsu_id() {
        return usu_id;
    }

    public void setUsu_id(int usu_id) {
        this.usu_id = usu_id;
    }

    public String getUsu_nom() {
        return usu_nom;
    }

    public void setUsu_nom(String usu_nom) {
        this.usu_nom = usu_nom;
    }

    public String getUsu_pass() {
        return usu_pass;
    }

    public void setUsu_pass(String usu_pass) {
        this.usu_pass = usu_pass;
    }
    
}
