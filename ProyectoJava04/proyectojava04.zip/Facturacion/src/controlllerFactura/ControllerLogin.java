/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlllerFactura;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modelo.Client;
import modelo.Conexion;
import modelo.Producte;

/**
 *
 * @author Roger
 */
public class ControllerLogin {
    public void addProducteClient(Producte p, Client c) {
        //1. conectarme
        Conexion conectar = new Conexion();
        Connection cn = conectar.conec();
        //creamos la primera consulta sql
        String sql1 = "INSERT INTO tbl_producte (pro_nombre, pro_precio ,pro_stock) VALUES (?,?,?)";

        //Creamos la segunda sentencia
        String sql2 = "INSERT INTO tbl_client (cli_nom, cli_nif) VALUES (?,?)";

        PreparedStatement pst1 = null;
        PreparedStatement pst2 = null;
        try {
            //solo hace una sentencia sql (false) hace dos sentencias (true)
            cn.setAutoCommit(false);

            pst1 = cn.prepareStatement(sql1);

            pst1.setString(1, p.getPro_nombre());
            pst1.setDouble(2, p.getPro_precio());
            pst1.setDouble(3, p.getPro_stok());

           
            
            cn.commit();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Conexion erronea");
            try {
                cn.rollback();
            } catch (SQLException ex) {
            }
        }
    }
}
