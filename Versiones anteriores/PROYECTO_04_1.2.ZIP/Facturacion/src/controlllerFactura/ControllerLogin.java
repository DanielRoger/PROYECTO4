/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlllerFactura;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modelo.Client;
import modelo.Conexion;
import modelo.Producte;
import modelo.Usuari;

/**
 *
 * @author Roger
 */
public class ControllerLogin {
    public void comprobarLogin (Usuari U) {
        //1. conectarme
        Conexion conectar = new Conexion();
        Connection cn = conectar.conec();

        try {
            //sql
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Conexion erronea");
        }
    }
}
